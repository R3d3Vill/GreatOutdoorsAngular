export class Wish{
    userId:string;
    productId:string;
    

    constructor(userId,productId)
    {
        this.userId=userId;
        this.productId=productId;
    }
}